package com.fkereki.mvpproject.client.clientSearch;

import com.fkereki.mvpproject.client.Display;

public interface ClientSearchDisplay
    extends Display {

}
