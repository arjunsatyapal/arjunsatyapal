package com.fkereki.mvpproject.client;

import com.google.gwt.user.client.Window;

public class HelloBrowserStdImpl {
  public void sayHello() {
    Window.alert("You don't have IE.");
  }
}
