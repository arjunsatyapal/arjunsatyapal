package com.fkereki.mvpproject.client.dtos;

public class SessionKeyServiceReturnDto
    extends GenericServiceReturnDto {

  public String encryptedSessionKey;

  public SessionKeyServiceReturnDto() {

  }
}
