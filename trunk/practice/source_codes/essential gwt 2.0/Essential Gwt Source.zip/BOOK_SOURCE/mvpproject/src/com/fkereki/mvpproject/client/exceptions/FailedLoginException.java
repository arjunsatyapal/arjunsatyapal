package com.fkereki.mvpproject.client.exceptions;

public class FailedLoginException
    extends Throwable {

  private static final long serialVersionUID = -4701655959857007577L;

  public FailedLoginException() {

  }
}
