package com.fkereki.mvpproject.client.exceptions;

public class PasswordNotChangedException
    extends Throwable {

  private static final long serialVersionUID = -2139888672014804668L;

  public PasswordNotChangedException() {

  }
}
