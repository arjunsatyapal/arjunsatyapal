package com.fkereki.mvpproject.client;

import com.google.gwt.user.client.ui.Widget;

/**
 * @author fkereki
 */
public interface Display {
  public Widget asWidget();
}
