/**
 * 
 */
package com.fkereki.mvpproject.client.i18n;

import com.fkereki.mvpproject.client.Display;

/**
 * @author fkereki
 */
public interface I18nDisplay
    extends Display {

}