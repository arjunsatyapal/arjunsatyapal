<?php
/*
 * Allow cross calls with FireFox 3.5, as per
 * https://developer.mozilla.org/En/HTTP_access_control
 */
header("Access-Control-Allow-Origin: *");

/*
 * Set the headers, so output will be seen as XML
 */
header("Content-type: text/xml");

$desiredCity= addslashes($_REQUEST["city"]);

$conn= mysql_connect("127.0.0.1", "gwtuser", "gwtpass");
mysql_select_db("gwtdb");

$result= mysql_query("SELECT ci.cityName, ci.countryCode, co.countryName,".
	"ci.stateCode, st.stateName, ci.population, ci.latitude, ci.longitude ".
	"FROM cities ci JOIN states st ON ".
	"ci.countryCode=st.CountryCode AND ci.stateCode=st.stateCode ".
	"JOIN countries co ON ci.countryCode=co.countryCode ".
	"WHERE ci.cityName LIKE '{$desiredCity}%' ".
	"ORDER BY co.countryName, st.stateName, ci.cityName ");

/*
 * Probably the simplest way to generate a XML document,
 * is by doing "echo" statements or by working with
 * strings.
 *
 * Let's create a XML document, with "cities"
 * as its root element.
 */
echo '<?xml version="1.0" encoding="UTF-8"?>'."\n";
echo '<cities>'."\n";

/*
 * Process all the found cities. Note that sometimes we use attributes, while other
 * times we use elements; this is just for variety, and not for any other reason.
 * 
 * Note that strings need be escaped; you cannot have "<", ">", and more, within
 * a string. If you are sure a certain string cannot include any special characters,
 * then you can send it out with no further ado.
 */
while ($row= mysql_fetch_assoc($result)) {
	echo ' <city name="'.htmlspecialchars($row['cityName']).'">'."\n";
	echo '  <country code="'.$row['countryCode'].'" ';
	echo 'name="'.htmlentities($row['countryName']).'"/>'."\n";
	echo '  <state code="'.$row['stateCode'].'" ';
	echo 'name="'.htmlentities($row['stateName']).'"/>'."\n";
	echo '  <coords>'."\n";
	echo '    <lat>'.$row['latitude'].'</lat>'."\n";
	echo '    <lon>'.$row['longitude'].'</lon>'."\n";
	echo '  </coords>'."\n";
	
	if ($row['population']>0) {
		echo '  <pop>'.$row['population'].'</pop>'."\n";
	}
	
	echo ' </city>'."\n";
}
echo '</cities>'."\n";
?>
