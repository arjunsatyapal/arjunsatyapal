<?php
/*                                                    
 * Allow cross calls with FireFox 3.5, as per         
 * https://developer.mozilla.org/En/HTTP_access_control
 */                                                    
header("Access-Control-Allow-Origin: *");  

/*
 * Set the headers, so output will be seen as XML
 */      
header("Content-type: text/xml");

$desiredCity= addslashes($_REQUEST["city"]);

$conn= mysql_connect("127.0.0.1", "mysqluser", "mysqlpass");
mysql_select_db("world");

$result= mysql_query("SELECT ci.cityName, ci.countryCode, co.countryName,".
	"ci.regionCode, re.regionName, ci.population, ci.latitude, ci.longitude ".
	"FROM cities ci JOIN regions re ON ".
	"ci.countryCode=re.CountryCode AND ci.regionCode=re.regionCode ".
	"JOIN countries co ON ci.countryCode=co.countryCode ".
	"WHERE ci.cityName LIKE '%{$desiredCity}%' ".
	"ORDER BY ci.cityName, co.countryName, re.regionName ");

/*
 * Using XmlWriter is another simple way to produce XML output.
 * 
 * Let's send the output directly to the caller; you could also
 * use openMemory() and work in memory, but there's no need here.
 * 
 * As an added advantage, you need not worry about escaping texts; 
 * this is done automatically by the methods.
 */
$writer =new XMLWriter();
$writer->openURI('php://output');

$writer->startDocument('1.0', 'UTF-8');
$writer->setIndent(true);	// this is just for aestetic purposes!
$writer->startElement("cities"); 

while ($row= mysql_fetch_assoc($result)) {
	$writer->startElement("city");
	$writer->writeAttribute("name", $row['cityName']);
	
	$writer->startElement("country");
	$writer->writeAttribute("code", $row['countryCode']);
	$writer->writeAttribute("name", $row['countryName']);
	$writer->endElement();
	
	$writer->startElement("region");
	$writer->writeAttribute("code", $row['regionCode']);
	$writer->writeAttribute("name", $row['regionName']);
	$writer->endElement();

	$writer->startElement("coords");
	$writer->writeElement("lat", $row['latitude']);
	$writer->writeElement("lon", $row['longitude']);
	$writer->endElement();
	
	if ($row['population']>0) {
		$writer->writeElement("pop", $row['population']);
	}
	
	$writer->endElement();	// city
}
$writer->endElement(); // cities 
?>
