<?php
/*
 * The SimpleXML functions are possibly the easiest way to get and process XML. Check
 * out, in the "foreach" loop below, how simple it is to get at any element or
 * attribute. 
 */

$xml_str= $_POST["xmldata"];
$xml_obj= simplexml_load_string($xml_str);

$conn= mysql_connect("127.0.0.1", "gwtuser", "gwtpass");
mysql_select_db("gwtdb");

foreach($xml_obj->children() as $city) {
  $name= addslashes($city['name']);
  $country= $city->country['code'];
  $state= $city->state['code'];
  $pop= $city->pop;
  
  /* If the input XML had the same format as the output XML,
   * we could get the latitude and longitude by writing:
   * $lat= $city->coords->lat;
   * $lon= $city->coords->lon;
   */
    
  mysql_query("UPDATE cities SET population='{$pop}' WHERE ".
    "countryCode='{$country}' AND ".
    "stateCode='{$state}' AND ".
    "cityName='{$name}'); 
}
?>
