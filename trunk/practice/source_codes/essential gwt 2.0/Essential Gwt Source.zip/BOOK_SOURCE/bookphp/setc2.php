<?php
$xml_str= $_REQUEST["xmldata"];

file_put_contents("/tmp/ungabunga", $xml_str);

echo "done";
?>
